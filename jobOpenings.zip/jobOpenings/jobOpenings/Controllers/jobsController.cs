﻿using System;
using System.Net;
using System.Web.Http;
using jobOpenings.Models;
using System.Net.Http;
using System.Data;

namespace jobOpenings.Controllers
{
    public class jobsController : ApiController
    {
        [HttpPost]
        public HttpStatusCode createJob(job input)
        {
            HttpStatusCode output = new HttpStatusCode();
            if (input == null)
            {
                return HttpStatusCode.BadRequest;
            }
            else
            {
                database objDB = new database();
                string[] arrParam = new string[6];
                try
                {
                    arrParam[0] = input.title;
                    arrParam[1] = input.description;
                    arrParam[2] = input.locationId.ToString();
                    arrParam[3] = input.departmentId.ToString();
                    arrParam[4] = input.closingDate.ToString();
                    arrParam[5] = "0";//create mode

                    if (objDB.insertDetails("usp_jobOpening_save", arrParam))
                    {
                        output = HttpStatusCode.Created;
                    }
                    else
                    {
                        output = HttpStatusCode.InternalServerError;
                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    objDB.Close();
                }
            }
            return output;
        }

        [HttpPut]
        public HttpStatusCode updateJob(job input)
        {
            HttpStatusCode output = new HttpStatusCode();
            if (input == null)
            {
                return HttpStatusCode.BadRequest;
            }
            else
            {
                database objDB = new database();
                string[] arrParam = new string[6];
                string id = "";
                try
                {
                    foreach (var parameter in Request.GetQueryNameValuePairs())
                    {
                        var key = parameter.Key;
                        var value = parameter.Value;
                        id = value;
                    }

                    arrParam[0] = input.title;
                    arrParam[1] = input.description;
                    arrParam[2] = input.locationId.ToString();
                    arrParam[3] = input.departmentId.ToString();
                    arrParam[4] = input.closingDate.ToString();
                    arrParam[5] = id;//update mode

                    if (objDB.insertDetails("usp_jobOpening_save", arrParam))
                    {
                        output = HttpStatusCode.OK;
                    }
                    else
                    {
                        output = HttpStatusCode.InternalServerError;
                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    objDB.Close();
                }
            }
            return output;
        }

        [HttpGet]
        public DataSet getJobDetails(string id)
        {
            DataSet dsTmp = new DataSet();
            if (id == null)
            {

            }
            else
            {
                database objDB = new database();
                string[] arrParam = new string[1];
               
                string[] arrTbl = new string[3];
                arrTbl[0] = "data";
                arrTbl[1] = "location";
                arrTbl[2] = "department";
                try
                {
                    arrParam[0] = id;
                    objDB.getDataset(arrParam, "usp_jobDetails_populate", dsTmp, arrTbl);
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    objDB.Close();
                }
            }
            return dsTmp;
        }
    }
}
