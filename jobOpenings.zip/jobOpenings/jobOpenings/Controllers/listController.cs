﻿using System;
using System.Net;
using System.Web.Http;
using jobOpenings.Models;
using System.Net.Http;
using System.Data;

namespace jobOpenings.Controllers
{
    public class listController : ApiController
    {
        [HttpPost]
        public DataSet getJobDetails(joblist input)
        {
            DataSet dsTmp = new DataSet();
            if (input == null)
            {
                //invalid request
            }
            else
            {
                database objDB = new database();
                string[] arrParam = new string[5];

                string[] arrTbl = new string[2];
                arrTbl[0] = "total";
                arrTbl[1] = "data";
                try
                {
                    arrParam[0] = input.q;
                    arrParam[1] = input.pageNo.ToString();
                    arrParam[2] = input.pageSize.ToString();
                    arrParam[3] = input.locationId.ToString();
                    arrParam[4] = input.departmentId.ToString();
                    objDB.getDataset(arrParam, "usp_jobList_populate", dsTmp, arrTbl);
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    objDB.Close();
                }
            }
            return dsTmp;
        }
    }
}
