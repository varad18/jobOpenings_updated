﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace jobOpenings.Models
{
    public class updateJob
    {
        [Required(ErrorMessage = "title required")]
        [StringLength(7, ErrorMessage = "title length is 7")]
        public string title { get; set; }

        [Required(ErrorMessage = "description required")]
        [StringLength(7, ErrorMessage = "description length is 7")]
        public string description { get; set; }

        [Required(ErrorMessage = "locationId required")]
        public int locationId { get; set; }

        [Required(ErrorMessage = "departmentId required")]
        public int departmentId { get; set; }

        [Required(ErrorMessage = "closingDate required")]
        public DateTime closingDate { get; set; }
    }
}