﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.ComponentModel;

namespace jobOpenings.Models
{
    public class database
    {
        #region ObjectManagement
        private IntPtr handle;
        private Component component = new Component();
        private bool disposed = false;
        public database(IntPtr handle)
        {
            this.handle = handle;
        }
        public database()
        {
            //constructor
        }
        #region IDisposable Members
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    component.Dispose();
                }
                CloseHandle(handle);
                handle = IntPtr.Zero;
            }
            disposed = true;
        }

        [System.Runtime.InteropServices.DllImport("Kernel32")]
        private extern static Boolean CloseHandle(IntPtr handle);
        ~database()
        {
            Dispose(false);
        }
        public void Close()
        {
            Dispose();
        }
        #endregion

        private System.Data.SqlClient.SqlConnection ConnectionTransaction;
        private System.Data.SqlClient.SqlTransaction TransacTrans;
        public string strReturn;
        public string Error = "";

        public void getDataset(string[] strSpParams, string strSpName, System.Data.DataSet ds, string[] arrTbl)
        {
            ConnectionTransaction = new SqlConnection(ConfigurationManager.AppSettings["strSQLCon"]);
            try
            {
                SqlHelper.FillDataset(ConnectionTransaction, strSpName, ds, arrTbl, strSpParams);
            }
            catch (Exception Ex)
            {
                Error = Ex.Message;
            }
            finally
            {
                if (ConnectionTransaction.State != ConnectionState.Closed)
                    ConnectionTransaction.Close();
            }
        }

        public bool insertDetails(string strSpName, string[] arrSpParam)
        {
            ConnectionTransaction = new SqlConnection(ConfigurationManager.AppSettings["strSQLCon"]);
            bool blnReturn = false;
            try
            {
                ConnectionTransaction.Open();
                TransacTrans = ConnectionTransaction.BeginTransaction();
                strReturn = SqlHelper.ExecuteScalar(TransacTrans, strSpName, arrSpParam).ToString();
                TransacTrans.Commit();
                blnReturn = true;
            }
            catch (Exception Ex)
            {
                strReturn = Ex.Message.ToString();
                blnReturn = false;
            }
            finally
            {
                ConnectionTransaction.Close();
            }
            return blnReturn;
        }
    }
}